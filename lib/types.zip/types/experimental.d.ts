export declare type THeaderEncoding = 'utf-8' | 'latin1';
